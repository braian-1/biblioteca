using bibliotecaDigital.Infrastructura;
using bibliotecaDigital.Models;
using Microsoft.AspNetCore.Mvc;

namespace bibliotecaDigital.Controllers;

public class LibrosController : Controller
{
    private readonly DbAppContext _context;

    public LibrosController(DbAppContext context)
    {
        _context = context;
    }
    
    public IActionResult Index()
    {
        var libros = _context.libros.ToList();
        return View(libros);
    }

    public IActionResult DeleteBook(int id)
    {
        var eleminar = _context.libros.Find(id);
        _context.libros.Remove(eleminar);
        _context.SaveChanges();
        return RedirectToAction("Index");
    }

    public IActionResult EditBook(int id)
    {
        var libros = _context.libros.Find(id);
        if (libros == null)
        {
            return NotFound();
        }

        return View(libros);
    }

    public IActionResult SaveEditBook(Libros libros)//Guardar los cambios del editar
    {
        _context.libros.Update(libros);
        _context.SaveChanges();
        return RedirectToAction("Index");
    }

    public IActionResult RegisterBook(Libros libros)
    {
        _context.libros.Add(libros);
        _context.SaveChanges();
        return RedirectToAction("Index");
    }
}