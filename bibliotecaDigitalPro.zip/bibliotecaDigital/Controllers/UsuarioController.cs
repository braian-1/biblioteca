using bibliotecaDigital.Infrastructura;
using bibliotecaDigital.Models;
using Microsoft.AspNetCore.Mvc;

namespace bibliotecaDigital.Controllers;

public class UsuarioController : Controller
{
    private readonly DbAppContext _context;

    public UsuarioController(DbAppContext context)
    {
        _context = context;
    }
    
    
    public IActionResult Index()
    {
        var usuarios = _context.usuarios.ToList();
        return View(usuarios);
    }

    public IActionResult Delete(int id)
    {
        var eleminar = _context.usuarios.Find(id);
        _context.usuarios.Remove(eleminar);
        _context.SaveChanges();
        return RedirectToAction("Index");
    }

    public IActionResult Edit(int id)
    {
        var usuario = _context.usuarios.Find(id);
        if (usuario == null)
        {
            return NotFound();
        }

        return View(usuario);
    }

    public IActionResult SaveEdit(Usuario usuario)//Guardar los cambios del editar
    {
        _context.usuarios.Update(usuario);
        _context.SaveChanges();
        return RedirectToAction("Index");
    }

    public IActionResult Register(Usuario usuario)
    {
        _context.usuarios.Add(usuario);
        _context.SaveChanges();
        return RedirectToAction("Index");
    }
}