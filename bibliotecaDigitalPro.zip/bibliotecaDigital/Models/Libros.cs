using System.ComponentModel.DataAnnotations;

namespace bibliotecaDigital.Models;

public class Libros
{
    [Key]
    public int Id { get; set; }
    
    public string Titulo { get; set; }
    
    public string autor { get; set; }
    
    public string Codigo { get; set; }
    
    public int EjemplaresDisponibles { get; set; }
    
}