using System.ComponentModel.DataAnnotations.Schema;

namespace bibliotecaDigital.Models;

public class Prestamos
{
    public int Id { get; set; }
    
    public int IdUser { get; set; }
    
    public int IdLibro { get; set; }
    
    public DateOnly FechaDevolucion { get; set; }
    
    [ForeignKey("IdUser")]
    public Usuario usuario { get; set; }
    
    [ForeignKey("IdLibro")]
    public Libros libros { get; set; }
}