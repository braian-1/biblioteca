using bibliotecaDigital.Models;
using Microsoft.EntityFrameworkCore;

namespace bibliotecaDigital.Infrastructura;

public class DbAppContext : DbContext
{
    public DbAppContext(DbContextOptions<DbAppContext> options) : base(options) { }
    
    public DbSet<Usuario> usuarios { get; set; }
    public DbSet<Libros> libros { get; set; }
    public DbSet<Prestamos> prestamos { get; set; }
}